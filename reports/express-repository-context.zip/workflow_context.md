# express — Context for AI

1 workflows · 0 risk findings · 56 verified connections · 289 code sections

Attach this file and `chunks.jsonl` together. Every code reference below identifies a source section in `chunks.jsonl`.

## 1. Business workflows

### 1. Dispatch HTTP requests and construct HTTP responses

Workflow ID: `business_path_7ab30d9a5954c94c`

An HTTP request is dispatched into the Express application; application or route code uses response helpers to produce and end an HTTP response.

**Purpose:** Obtain a response to an HTTP request

**Business outcome**

- Returns application content to a caller
- Provides JSON or rendered view output where application code selects those helpers

**Important behavior and rules**

- For HEAD requests, send no response body.
- For a fresh request, set status 304; for 204 or 304 responses, remove content and transfer headers and send an empty body.
- A JSONP callback is taken from the configured query parameter and restricted to characters matching the callback allowlist before constructing the JavaScript response.
- For a HEAD request, end the response without sending the body.
- Only generate an ETag when no ETag is already set and the application ETag function is callable.

**Identified functions:** `app.handle(req, res, callback)`, `res.send(body)`, `res.json(obj)`, `res.render(view, options, callback)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `lib/response.js` | `chunk_51f2a025e7dfcde1` |
| Source section | `lib/response.js` | `chunk_928c7d54e9232f9c` |
| Source section | `lib/response.js` | `chunk_99fd8d613910b6a5` |
| Source section | `lib/application.js` | `chunk_bbdceaa326819432` |

## 2. Verified code connections and remaining repository context

Connections are static source relationships; they do not prove runtime execution.

- `chunk_0b7492cbdc306d56` → `chunk_d3c73278743f76a2`: imports_module; symbol: not specified
- `chunk_0b7492cbdc306d56` → `chunk_d3c73278743f76a2`: file_import; symbol: not specified
- `chunk_14529e1921142155` → `chunk_d3c73278743f76a2`: imports_module; symbol: not specified
- `chunk_14529e1921142155` → `chunk_d3c73278743f76a2`: file_import; symbol: not specified
- `chunk_2416de272c6d69e4` → `chunk_d3c73278743f76a2`: imports_module; symbol: not specified
- `chunk_2416de272c6d69e4` → `chunk_d3c73278743f76a2`: file_import; symbol: not specified
- `chunk_2cb5dada53af71fb` → `chunk_49e49b3d5f23b013`: imports_module; symbol: not specified
- `chunk_2cb5dada53af71fb` → `chunk_49e49b3d5f23b013`: file_import; symbol: not specified
- `chunk_2cb5dada53af71fb` → `chunk_dc571d8c91a08afe`: imports_module; symbol: not specified
- `chunk_2cb5dada53af71fb` → `chunk_dc571d8c91a08afe`: file_import; symbol: not specified
- `chunk_2cb5dada53af71fb` → `chunk_f85f23cdb000e2d7`: imports_module; symbol: not specified
- `chunk_2cb5dada53af71fb` → `chunk_f85f23cdb000e2d7`: file_import; symbol: not specified
- `chunk_3146224d25b780bd` → `chunk_9a2f4e7d3d653ee8`: imports_module; symbol: not specified
- `chunk_3146224d25b780bd` → `chunk_9a2f4e7d3d653ee8`: file_import; symbol: not specified
- `chunk_3716d88bb3dbe7bd` → `chunk_d3c73278743f76a2`: imports_module; symbol: not specified
- `chunk_3716d88bb3dbe7bd` → `chunk_d3c73278743f76a2`: file_import; symbol: not specified
- `chunk_377407a692387e0b` → `chunk_868d5d7ade5a0aaa`: imports_module; symbol: not specified
- `chunk_377407a692387e0b` → `chunk_868d5d7ade5a0aaa`: file_import; symbol: not specified
- `chunk_377407a692387e0b` → `chunk_928c7d54e9232f9c`: imports_module; symbol: not specified
- `chunk_377407a692387e0b` → `chunk_928c7d54e9232f9c`: file_import; symbol: not specified
- `chunk_377407a692387e0b` → `chunk_bbdceaa326819432`: imports_module; symbol: not specified
- `chunk_377407a692387e0b` → `chunk_bbdceaa326819432`: file_import; symbol: not specified
- `chunk_392d3f68cb636dcc` → `chunk_8b43eeb0c6d02d67`: imports_module; symbol: not specified
- `chunk_392d3f68cb636dcc` → `chunk_8b43eeb0c6d02d67`: file_import; symbol: not specified
- `chunk_4e385838bdfd1db2` → `chunk_b111edf3daeeb8f6`: imports_module; symbol: not specified
- `chunk_4e385838bdfd1db2` → `chunk_b111edf3daeeb8f6`: file_import; symbol: not specified
- `chunk_6757516acce7a069` → `chunk_d3c73278743f76a2`: imports_module; symbol: not specified
- `chunk_6757516acce7a069` → `chunk_d3c73278743f76a2`: file_import; symbol: not specified
- `chunk_71318b540ce3c09e` → `chunk_d3c73278743f76a2`: imports_module; symbol: not specified
- `chunk_71318b540ce3c09e` → `chunk_d3c73278743f76a2`: file_import; symbol: not specified
- `chunk_7a771658a9ecc201` → `chunk_984f583c746baa0f`: imports_module; symbol: not specified
- `chunk_7a771658a9ecc201` → `chunk_984f583c746baa0f`: file_import; symbol: not specified
- `chunk_7dc4a05713b6bb01` → `chunk_9a2f4e7d3d653ee8`: imports_module; symbol: not specified
- `chunk_7dc4a05713b6bb01` → `chunk_9a2f4e7d3d653ee8`: file_import; symbol: not specified
- `chunk_7e3c7481cc7d6c9d` → `chunk_377407a692387e0b`: imports_module; symbol: not specified
- `chunk_7e3c7481cc7d6c9d` → `chunk_377407a692387e0b`: file_import; symbol: not specified
- `chunk_928c7d54e9232f9c` → `chunk_344d98fc844cdbec`: imports_module; symbol: not specified
- `chunk_928c7d54e9232f9c` → `chunk_344d98fc844cdbec`: file_import; symbol: not specified
- `chunk_a5e14a3b1fc928ff` → `chunk_d3c73278743f76a2`: imports_module; symbol: not specified
- `chunk_a5e14a3b1fc928ff` → `chunk_d3c73278743f76a2`: file_import; symbol: not specified
- `chunk_aabbfb6badb523ae` → `chunk_d3c73278743f76a2`: imports_module; symbol: not specified
- `chunk_aabbfb6badb523ae` → `chunk_d3c73278743f76a2`: file_import; symbol: not specified
- `chunk_accefb3600dbe3f8` → `chunk_d3c73278743f76a2`: imports_module; symbol: not specified
- `chunk_accefb3600dbe3f8` → `chunk_d3c73278743f76a2`: file_import; symbol: not specified
- `chunk_bbdceaa326819432` → `chunk_344d98fc844cdbec`: imports_module; symbol: not specified
- `chunk_bbdceaa326819432` → `chunk_344d98fc844cdbec`: file_import; symbol: not specified
- `chunk_bbdceaa326819432` → `chunk_b75b41e89dde48b8`: imports_module; symbol: not specified
- `chunk_bbdceaa326819432` → `chunk_b75b41e89dde48b8`: file_import; symbol: not specified
- `chunk_d829831dd576ed93` → `chunk_19d01f99203a3935`: imports_module; symbol: not specified
- `chunk_d829831dd576ed93` → `chunk_19d01f99203a3935`: file_import; symbol: not specified
- `chunk_d829831dd576ed93` → `chunk_74f66f7dc3e97fd1`: imports_module; symbol: not specified
- `chunk_d829831dd576ed93` → `chunk_74f66f7dc3e97fd1`: file_import; symbol: not specified
- `chunk_e1d3e7e529ed9187` → `chunk_8b43eeb0c6d02d67`: imports_module; symbol: not specified
- `chunk_e1d3e7e529ed9187` → `chunk_8b43eeb0c6d02d67`: file_import; symbol: not specified
- `chunk_f6d7b9334785d116` → `chunk_f4a8b82b9340724a`: imports_module; symbol: not specified
- `chunk_f6d7b9334785d116` → `chunk_f4a8b82b9340724a`: file_import; symbol: not specified

Other source sections remain available in `chunks.jsonl`; code is stored only once.

## 3. Business risks

Analysis status: **NO_REPORTABLE_FINDINGS**

No reportable risk findings. This does not mean the repository is risk-free.
